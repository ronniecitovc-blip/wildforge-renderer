import React from "react";
import { Composition } from "remotion";
import { WildForgeVideo, WildForgeProps, sampleProps } from "./WildForgeVideo";
export const RemotionRoot: React.FC = () => {
  return (
    <Composition<WildForgeProps>
      id="WildForgeVideo"
      component={WildForgeVideo}
      durationInFrames={1800}
      fps={30}
      width={1080}
      height={1920}
      defaultProps={sampleProps}
    />
  );
};
