import fs from "fs";
import path from "path";
const inputFile = process.argv[2] || "input/manifest.json";
const outputFile = process.argv[3] || "output/manifest.normalized.json";
const raw = fs.readFileSync(inputFile, "utf8");
const data = JSON.parse(raw);
const script = String(data.script || data.narration_text || "");
const fallbackScenes = script.split(/(?<=[.!?])\s+/).filter(Boolean).slice(0, 7).map((sentence, i) => ({
  segundos: `${i * 8}-${(i + 1) * 8}`,
  visual: "Fondo documental dinámico con profundidad, partículas y movimiento suave",
  texto_pantalla: sentence.length > 78 ? sentence.slice(0, 75) + "..." : sentence
}));
const normalized = {
  slot: data.slot || 1,
  video_id: data.video_id || `WF-${Date.now()}`,
  topic: data.topic || "Microdocumental animal",
  title: data.title || data.topic || "Dato sorprendente de la naturaleza",
  description: data.description || "",
  hashtags: data.hashtags || "#naturaleza #animales #ciencia",
  scheduled_time: data.scheduled_time || "",
  script,
  scenes: Array.isArray(data.scenes) && data.scenes.length ? data.scenes : fallbackScenes,
  render: { aspect_ratio: "9:16", resolution: "1080x1920", duration_target_seconds: Number(data.render?.duration_target_seconds || 60) }
};
fs.mkdirSync(path.dirname(outputFile), { recursive: true });
fs.writeFileSync(outputFile, JSON.stringify(normalized, null, 2), "utf8");
console.log(`Normalized manifest written to ${outputFile}`);
