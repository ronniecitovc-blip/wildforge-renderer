# WildForge Renderer

Renderizador MP4 para WildForge AI usando Remotion + GitHub Actions.

## Flujo

1. n8n genera el guion y el manifest.
2. n8n sube el manifest al repositorio GitHub.
3. GitHub Actions renderiza el MP4.
4. GitHub envía el MP4 al webhook de n8n.
5. n8n sube el MP4 a Google Drive.
6. Tú publicas manualmente en TikTok.

## Primer test manual

1. Sube este proyecto a un repositorio GitHub.
2. Entra a Actions.
3. Ejecuta `Render WildForge MP4`.
4. Usa `input/manifest.json` y `wildforge_video_1.mp4`.
5. Deja `callback_url` vacío para probar solo artifact.

## Callback n8n

Importa `n8n/wildforge_render_callback_import.json` o crea el workflow equivalente.

URL esperada al publicarlo:
`https://anonimmato.app.n8n.cloud/webhook/wildforge/render-callback`
